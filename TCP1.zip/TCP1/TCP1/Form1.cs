﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TCP1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        const int port = 50000;
        private void startButton_Click(object sender, EventArgs e)
        {
            IPAddress ip = IPAddress.Parse("127.0.0.1");
            TcpListener server = null;

            try
            {
                server = new TcpListener(ip, port);
                server.Start();

                if (server != null)
                    outputLabel.Text = "Server has been started \n";

                while (true)
                {
                    outputLabel.Text = "Waiting for the connection... \n";
                    
                   // получаем входящее подключение
                    TcpClient client = server.AcceptTcpClient();
                    outputLabel.Text = "The client has been connected. Executing request...\n";
                    
                   // получаем сетевой поток для чтения и записи
                    NetworkStream stream = client.GetStream();
                    
                  // сообщение для отправки клиенту
                     string response = "Hello world";
                  // преобразуем сообщение в массив байтов
                     byte[] data = Encoding.UTF8.GetBytes(response);
                    
                  // отправка сообщения
                     stream.Write(data, 0, data.Length);
                     outputLabel.Text = "Message has been sent: {0}" + response;
                  // закрываем поток
                     stream.Close();
                   
                  // закрываем подключение
                     client.Close();
                     
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception.Message);
            }
            finally
            {
                if (server != null)
                    server.Stop();
                else MessageBox.Show("Server hasn't been started!");
            }
        }

        private void outputLabel_Click(object sender, EventArgs e)
        {

        }

   }

}
